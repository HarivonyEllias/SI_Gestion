import { Component } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { HostListener } from '@angular/core';

@Component({
  selector: 'app-data',
  templateUrl: './data.component.html',
  styleUrls: ['./data.component.css']
})
export class DataComponent {
  myData = { name: 'John', age: 30, email: 'john@example.com' };
  responseMessage = '';

  constructor(private http: HttpClient) { }

  sendData() {
    const url = 'http://localhost:3000/submit-data'; // replace with your server API URL
    this.http.post(url, this.myData).subscribe((response: any) => {
      console.log(response);
      this.responseMessage = `You are ${response.name},${response.age},${response.email}`;
    }, error => {
      console.error(error);
      this.responseMessage = 'An error occurred while sending data';
    });
  }

  @HostListener('click', ['$event.target'])
  onClick(btn: any) {
    if (btn.value === 'send') {
      this.sendData();
    }
  }
}
